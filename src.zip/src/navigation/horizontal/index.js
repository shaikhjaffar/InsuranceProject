// import { Mail, Home } from "react-feather"

export default [
  {
    id: "home",
    title: "Home",
    // icon: <Home size={20} />,
    navLink: "/home"
  },
  {
    id: "Product",
    title: "Product",
    // icon: <Mail size={20} />,
    navLink: "/product-page"
  },
  {
    id: "Blogs",
    title: "Blogs",
    // icon: <Mail size={20} />,
    navLink: "/blog"
  },
  {
    id: "Career",
    title: "Career",
    // icon: <Mail size={20} />,
    navLink: "/career"
  },
  {
    id: "About",
    title: "About us", 
    // icon: <Mail size={20} />,
    navLink: "/about"
  },
  {
    id: "Contact",
    title: "Contact us", 
    // icon: <Mail size={20} />,
    navLink: "/contact"
  }
]
