import React from "react"
import "@styles/base/components/_card.scss"
class About extends React.Component {
    render() {
        return (
        <div className="Product card"style={{height:4936}}>
            <h1>about</h1>
        </div>
        )
    }
}
export default  About