import Product from "../pages/Product/index"
import Feature from "../pages/Feature"
import About from "../pages/About"
import Award from "../pages/Award/index"
import Collab from "../pages/Collab/index"
import Stats from "../pages/stats/index"
import MainPage from "../pages/MainPage/index"
const Home = () => {
  return (
   <>
   <MainPage/>
   <Product/>
   <Feature/>
   <About/>
   <Award/>
   <Collab/>
   <Stats/>
   </>
  )
}

export default Home
