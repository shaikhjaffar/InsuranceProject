import React from "react"
import "@styles/base/components/_card.scss"
class Product extends React.Component {
    render() {
        return (
        <div className="Product card"style={{height:4936}}>
            <h1>Product</h1>
        </div>
        )
    }
}
export default  Product