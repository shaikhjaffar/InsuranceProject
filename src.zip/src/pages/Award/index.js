import React from "react"
import "@styles/base/components/_card.scss"
import './style.css'
import Award1 from './images/Achievers.png'
import Award2 from './images/Award2image.png'
class Award extends React.Component {
    render() {
        return (
        <div className="Award card" style={{height:825}}>
            <span className="header">Best Fintech Startup of the year 2022</span>
            <span style={{display:"flex"}}>
            <div  className='container1'>
        <img className='imagesize' src={Award1} alt="BigCo Inc. logo"/>
        </div>
        <div  className='container1'>
        <img className='imagesizss' src={Award2} alt="BigCo Inc. logo"/>
        </div>
        </span>
        </div>
        )
    }
}
export default  Award