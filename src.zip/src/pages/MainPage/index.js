import React from "react"
import "@styles/base/components/_card.scss"
import Form from "../../@core/components/form"
// import { Card } from "reactstrap"
 import './main.css'
import Effect from "../../@core/components/m_effect"
 import  {ReactComponent as Recsvg}  from "@src/assets/images/pages/rectangle.svg"

const MainPage = () => {
  return (
    <>
      <div className="card">
        <div className="row">
          <div className="column">
            <div className="topsvg">
              <Recsvg className="rec-svg"/>
            </div>
            <div className="company-motto">
              <div className="motto1">
                <p>Hamesha Aapke Saath</p>
              </div>
            </div>
            <p className="motto2">Listening to the Financial Needs of Business and Simplifying Payroll Funding for Digital India</p>
            <div className="text-animation">
              <Effect />
            </div>
            <div className="bottomsvg">
              <Recsvg className="rec-svg"/>
            </div>
          </div>
          <div className="column form">
            <h3 className="form-msg-h3">Get a Free Quote</h3>
            <p className="form-msg-p">Striving to get you the best financial solutions
                to grow your business with ease and stability.</p>
            <div className="main-form">
              <Form />
            </div>
          </div> 
        </div>
      </div>
    </>
  )
}

export default MainPage
