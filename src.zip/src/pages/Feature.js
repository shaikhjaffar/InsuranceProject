import React from "react"
import "@styles/base/components/_card.scss"
class Feature extends React.Component {
    render() {
        return (
        <div className="Feature card"style={{height:1357}}>
            <h1>Feature</h1>
        </div>
        )
    }
}
export default  Feature