import React from "react"
import "@styles/base/components/_card.scss"

import { useInView } from 'react-intersection-observer'

const about = () => {
  const { ref, inView } = useInView({
    triggerOnce: true,
    rootMargin: '0px'
  })

  return (
    <div className="about card" style={{height:1324}}>
          <div
      ref={ref}
      className={`transition-opacity ${inView ? 'opacity-1' : 'opacity-0'}`}
    >
      <span aria-label="Wave"><h1>heloo ajOICJOSLKJCOIJWCIWNCWM</h1></span>
    </div>
        </div>
    
  )
}

export default about