import React from "react"
import { gsap } from "gsap"
import './style.css'
const { useLayoutEffect, useRef } = React
function Effect() {
    const app = useRef()
   useLayoutEffect(() => {
     const ctx = gsap.context(() => {
        gsap.to(".div1",{x:1000,y:1100,duration:4})
        let t1=gsap.timeline()
      t1.fromTo(".svg2", {x:275,y:300},{x:275,y:120,duration:1.5,})
     t1.fromTo( ".svg1",{ x:500,y:60},{x:500,y:-300,duration:2,fill:"orange"})
     }, app)
     return () => ctx.revert()
   })
   return (
    <h1 className="motto3" ref={app}>
    <span>1 Click To   </span>
    <span className="auto-input"></span>
    </h1> 
   )
 }