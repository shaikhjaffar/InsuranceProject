// ** Dropdowns Imports
import React from "react"
// import { Button } from "reactstrap"
 import './style.css'
 import login from './Group 87.svg'
 import Register from './Group 86.svg'
const button = () => {
  return (
    <>
    <img src={Register} className="button-animate bt1" alt="Register"></img>
    <img src={login} className="button-animate bt2" alt="login"></img>
    </>

  )
}
export default button
