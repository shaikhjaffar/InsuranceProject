// import "./App.css";
import NavBar from "./pages/navbar/nav"
import { Routes, Route } from 'react-router-dom'
// import {Switch} from 'react-router-dom'
import About from './views/about/About'
import Blog from './views/blog'
import Stats from './pages/stats/index'
import Home from './views/Home'
import Product from "./views/product-page/index"
import Contactus from './pages/Footer/Footer'
import Sidebar from "./@core/components/hamburgernav/sidemenu/sidemenu"
function App() {
  return (
    <>
<div className="App" id="outer-container">
      <Sidebar pageWrapId={'page-wrap'} outerContainerId={'outer-container'} />
      <div id="page-wrap">
      <NavBar />
      <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/product' element={<Product/>} />
          <Route path='/blogs' element={<Blog/>} />
          <Route path='/carrer' element={<Stats/>} />
          <Route path='/about-us' element={<About/>} />
          <Route path='/contact-us' element={<Contactus/>} />
      </Routes>
      </div>
    </div>
      
    </>
  )
}

export default App