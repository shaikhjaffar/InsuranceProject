import {React, Component} from "react"
import SecondPage from "../../@core/components/Productmax/SecondPage"
import Collabtionanimation from "../../@core/components/Productmin/Collabtionanimation"

export default class Product extends Component {

  constructor(props) {
     super(props)
     const width = window.innerWidth
     this.state = {}
     if (width > 480) {
       this.state.renderComponent = (
        <SecondPage/>
       )
     } else {
       this.state.renderComponent = (
        <Collabtionanimation/>
       )
     }
   }

  render() {
    return this.state.renderComponent
  }

}
