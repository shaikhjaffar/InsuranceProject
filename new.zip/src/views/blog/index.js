import React, { useRef, useState } from "react"
import "@styles/base/components/_card.scss"
import "./style.css"
import image1 from "./images/image 64.png"
import Calendar from "../../@core/components/calendar"
const Blog = () => {
  const [show, setShow] = useState(false)
  const ref = useRef()
  const ref1 = useRef()
  function display () {
    setShow(true)
    const nodeList = document.querySelectorAll(".blog-image")
    for (let i = 0; i < nodeList.length; i++) {
      nodeList[i].classList.add('animation')
    }
    ref1.current.style.height = "50rem" 
  }
 
    return (
      <div className="blog card">
        <input className="search" type="text" placeholder="Search here" />
        <section className="calendar">
          <Calendar />
        </section>
        <section className="main">
          <div className="content">
            <div className="image-blog-container">
              <span className="black" ref={ref1}></span>
              <img className="blog-image" ref={ref} src={image1}></img>
            </div>
            <div>
              <h1>
                4 Ways to be
                <br></br>Financially Independent
              </h1>
              <p>
                # Calculating budgets, Calculate budget, financial dependency,
                financially independent, Money Management how to become
                financially independent
              </p>
              <p>
                In this day and age it is very important to be financially
                independent and there are ways in which you can achieve your
                goal.
              </p>
              <h3>Make a Budget and Stick to It</h3>
              <p>
                It is important to know how much your spendings are and how much
                your savings are in order to know your way to financial
                independence. One must understand how much money they would
                require to become independent financially. It usually turns out
                to be more than estimated. Evaluating what your current status
                is financially and how much work you would have to do in the
                following years to reach your goal. Make a budget as to how
                where and how much time will you need and where most of your
                money is going so that you know where you can cut down on.
              </p>
              <div className="read-more" style={{
          display: show ? "Block" : "none"
        }}>
                <h3>Spend Prudently</h3>
                <p>
                  Now that you know your budget well, where you spend more than
                  needed and where you don’t, it’s time to control those
                  spendings. It is important to make sound judgment and money
                  management choices to fulfil your financial goal. It’s crucial
                  to not only make a spending budget but also to strictly adhere
                  to it. Lessen your debts and all avoidable expenses as much as
                  you can. You can save money on these three aspects which are
                  usually the biggest expenses that are; transportation costs,
                  housing costs and food expenditure. To be financially
                  independent in the future you might have to make some
                  sacrifices in the present and live an economical lifestyle.
                </p>
                <h3>Have Multiple Sources of Income</h3>
                <p>
                  It is not wise to just depend on your day job or full time job
                  as your only source of income. The job market is not stable
                  and so is the economy. In such circumstances one needs to look
                  out for opportunities to earn extra and have more than one
                  source of income. Maybe it’s time to finally start a new
                  venture you have always dreamed of by raising capital. One
                  should always have an alternate source of income as a backup
                  in the event that one lose their job for some reason. Plus it
                  is known that the rich and financially independent never have
                  just one source of income. They always have multiple channels
                  of income to support their lifestyle. One of the most advised
                  way of income is to invest your money somewhere you can earn a
                  passive source of income. Passive source of income means when
                  you are making money even when you are not actively working.
                  Make money while you are sleeping is the phrase many rich
                  people use.
                </p>
                <h3>Focus on Investing Your Money</h3>
                <p>
                  Weather the market conditions are good or bad investments
                  should be on your plate of financial decisions. When investing
                  keep in mind to diversify your portfolio and not put all your
                  money in one place. Like they say don’t put all your eggs in
                  one basket. When you plan on investing do your research
                  thoroughly and educate yourself on the various schemes and
                  portfolios. Once you make a budget, stick to it, reduce your
                  spendings you can start investing and slowly look for other
                  income options that will earn you a passive income.
                </p>
              </div>
              <button className="read" onClick={display}>Read more</button>
            </div>
          </div>
          <div className="content"style={{
          display: show ? "none" : "flex"
        }}>
            <image className="image-blog-container">
              <span className="black"></span>
              <img className="blog-image" src={image1}></img>
            </image>
            <div>
              <h1>
                4 Ways to be
                <br></br>Financially Independent
              </h1>
              <p>
                # Calculating budgets, Calculate budget, financial dependency,
                financially independent, Money Management how to become
                financially independent
              </p>
              <p>
                In this day and age it is very important to be financially
                independent and there are ways in which you can achieve your
                goal.
              </p>
              <h3>Make a Budget and Stick to It</h3>
              <p>
                It is important to know how much your spendings are and how much
                your savings are in order to know your way to financial
                independence. One must understand how much money they would
                require to become independent financially. It usually turns out
                to be more than estimated. Evaluating what your current status
                is financially and how much work you would have to do in the
                following years to reach your goal. Make a budget as to how
                where and how much time will you need and where most of your
                money is going so that you know where you can cut down on.
              </p>
              <button className="read">Read more</button>
            </div>
          </div>
        </section>
        <section className="more" style={{
          display: show ? "Block" : "none"
        }}>
          <span className="black-line"></span>
          <h3 className="option-heading">You Might also like</h3>
          <div className="option">
            <card>
              <img  className="option-image" src={image1} alt="opt1"></img>
              <p>4 Ways to be Financially Independent</p>
            </card>
            <card>
              <img className="option-image" src={image1} alt="opt1"></img>
              <p>4 Ways to be Financially Independent</p>
            </card>
            <card>
              <img className="option-image" src={image1} alt="opt1"></img>
              <p>4 Ways to be Financially Independent</p>
            </card>
            <card>
              <img  className="option-image"src={image1} alt="opt1"></img>
              <p>4 Ways to be Financially Independent</p>
            </card>
          </div>
        </section>
        <section className="blog-footer"style={{
          display: show ? "Block" : "none"
        }}>
        <span className="black-line"></span>
        <h3 className="comment-heading">Leave a Reply</h3>
        <input type="text" className="comment-section" placeholder="Your Comment here....."></input>
        <div className="comment-details">
        <input type="text" className="blog-comment-details" placeholder="Name required"></input>
        <input type="text" className="blog-comment-details" placeholder="Email required"></input>
        <input type="text" className="blog-comment-details" placeholder="Website"></input>
        </div>
        </section>
      </div>
    )
  }

export default Blog
