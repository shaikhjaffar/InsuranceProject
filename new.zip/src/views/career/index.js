import React from "react"
import "@styles/base/components/_card.scss"
class Career extends React.Component {
    render() {
        return (
        <div className="Product card"style={{height:4936}}>
            <h1>Career</h1>
        </div>
        )
    }
}
export default  Career