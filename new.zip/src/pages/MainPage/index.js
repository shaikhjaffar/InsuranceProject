import React from "react"
import "@styles/base/components/_card.scss"
import Form from "../../@core/components/form"
// import { Card } from "reactstrap"
 import './main.css'
import Effect from "../../@core/components/m_effect"
 import  Recsvg  from "@src/assets/images/pages/rectangle.svg"
 import topsvg from "./Group 80.png"

const MainPage = () => {
  return (
    <>
      <div className="card">
        <div className="row">
          <div className="column">
          <img className="topsvg" src={topsvg}>
            </img>
            <div className="company-motto">
              <div className="motto1">
                <p>Hamesha Aapke Saath</p>
              </div>
            </div>
            <p className="motto2">Listening to the Financial Needs of Business and Simplifying Payroll Funding for Digital India</p>
            <div className="text-animation">
              <Effect />
            </div>
          </div>
          <div className="column form">
            <h3 className="form-head" style={{marginLeft:5}}>Get a Free Quote</h3>
            <p className="form-msg-p">Striving to get you the best financial solutions
                to grow your business with ease and stability.</p>
            <div className="main-form">
              <Form />
            </div>
          </div> 
        </div>
        <img className="bottomsvg" src={Recsvg}>
            </img>
      </div>
      
    </>
  )
}

export default MainPage
