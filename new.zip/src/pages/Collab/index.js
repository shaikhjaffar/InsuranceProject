
import Slider from 'react-slick'
import "@styles/base/components/_card.scss"
 import './collab.css'
 import Heading from "../../@core/components/headingeffect"
import CompanyLo1 from './images/image001.png'
import CompanyLo2 from './images/image002.png'
import CompanyLo3 from './images/image003.png'
import CompanyLo4 from './images/image004.png'
import CompanyLo5 from './images/image005.png'
import CompanyLo6 from './images/image006.png'
function Collab() {
    const settings = {
        dots: true,
        infinite: false,
        speed: 500,
        autoplay: true,
        slidesToShow: 4,
        slidesToScroll: 4,
        initialSlide: 0,
        responsive: [
          {
            breakpoint: 1280,
            settings: {
              slidesToShow: 4,
              slidesToScroll: 6,
              infinite: true,
              spaceBetwee:30,
              dots: true
            }
          },
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 3,
              infinite: true,
              dots: true,
              spaceBetween: 15
            }
          },
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 2,
              initialSlide: 2,
              spaceBetween: 15
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 2,
              spaceBetween: 10
            }
          },
          {
            breakpoint: 240,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1,
              spaceBetween: 10
            }
          }
        ]
      }
      return (
       
        <div className="card">
          <Heading/>
           <Slider {...settings} className="collab-slider">
            <div className="comp">
            <img  className="siz" src={CompanyLo1} alt="BigCo Inc. logo"/>
            </div>
            <div className="comp">
            <img className="siz" src={CompanyLo2} alt="BigCo Inc. logo"/>
            </div>
            <div className="comp">
            <img className="siz" src={CompanyLo3} alt="BigCo Inc. logo" />
            </div>
            <div className="comp">
            <img className="siz" src={CompanyLo4} alt="BigCo Inc. logo"/>
            </div>
            <div className="comp">
            <img className="sizy" src={CompanyLo5} alt="BigCo Inc. logo"/>
            </div>
            <div className="comp">
            <img className="sizz" src={CompanyLo6} alt="BigCo Inc. logo"/>
            </div>
            </Slider>
            </div>
           
        
      )
}
export default  Collab
