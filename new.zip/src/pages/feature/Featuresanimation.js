import React from 'react'
import './Feature.css'
import F1 from './images/poster.svg'
import F2 from './images/247.svg'
import F3 from './images/post.svg'
import F4 from './images/featherfeature.svg'
import F5 from './images/rupeefeature.svg'
import F6 from './images/cloak.svg'
import { gsap } from "gsap"
import { ScrollTrigger } from "gsap/ScrollTrigger"
gsap.registerPlugin(ScrollTrigger)
const { useRef, useEffect } = React
function HeadingFeature() {
    const headingref = useRef(null)
    useEffect(() => {
        const wordmark = document.querySelector('.wordmark-title-feature')
        const tl = gsap.timeline({
            scrollTrigger: {
                // markers: true,
                trigger: document.querySelector('.container-gsap-feature'),
                start: "top 60%",
                end: "bottom 20%",
                scrub: true,
                repeat:0
            }
        })
        tl.to(wordmark, {
            width: "10px"
        })
    }, [])
    return (
        <div class="container-gsap-feature" ref={ headingref } id="container-feature">
        <div class="wordmark-title-feature"></div>
        <div class="title-rect1"></div>
    <div class="title-rect2"></div>
    </div>
     
    )
  }

function Featuresanimation() {
    return (
        <div className="card">
            <HeadingFeature />
            <div className='row-feature'>
                <div className='column-feature'>
            <div className="tab1    ">
                <div className="rcorners">
                    <div className="rcircle">
                        <div className="rcircle1">
                            <img className='FeaturekiImg' src={F1} alt="BigCo Inc. logo"/>
                        </div>  
                    </div>
                </div>
                 <div className="rcorners-title"> 
                    <h4 >Limited Paperwork</h4>  
                </div>
                <div className="rcorners-text">
                    <p className='text'>1 Click Capital recognizes the value of your time and resources, so we ask for minimal
                        paperwork to process your application.</p>
                </div>
            </div>       
            <div className="tab1    ">
                <div className="rcorners">
                    <div className="rcircle">
                        <div className="rcircle1">
                            <img className='FeaturekiImg'src={F2} alt="BigCo Inc. logo"/>
                        </div>  
                    </div>
                </div>
                <div className="rcorners-title">  
                    <h4 >24 x 7 Utilisation</h4>  
                </div>
                <div className="rcorners-text">
                    <p className='text'>You can use your funds any time of the  day or night 24x7 as soon as your limit
                        is generated in the 1 Click System.</p>
                </div>
            </div>
            <div className="tab1    " >
                <div className="rcorners">
                    <div className="rcircle">
                        <div className="rcircle1">
                            <img className='FeaturekiImg'src={F3} alt="BigCo Inc. logo"/>
                        </div>  
                    </div>
                </div>
                <div className="rcorners-title">
                    <h4 >Immediate Access</h4>
                </div>
                <div className="rcorners-text">
                    <p className='text'>Enjoy immediate access to funds as soon as you’ve been approved.
                        All you have to do is ask for it.</p>
                </div>
            </div>  
            </div>
            <div className='column-feature'>   
            <div className="tab1    ">
                <div className="rcorners">
                    <div className="rcircle">
                        <div className="rcircle1">
                            <img className='FeaturekiImg'src={F4} alt="BigCo Inc. logo"/>
                        </div>  
                    </div>
                </div>
                <div className="rcorners-title">
                    <h4 >Speed & Ease</h4>
                </div>
                <div className="rcorners-text">
                    <p className='text'>Uncertainty is undoubtedly the most formidable 
                        foe of prepara-tion. It is our aim to bring clarity to your application within
                        48 hours of submission.</p>
                </div>
            </div>
            <div className="tab1    ">
                <div className="rcorners">
                    <div className="rcircle">
                        <div className="rcircle1">
                            <img className='FeaturekiImg'src={F5} alt="BigCo Inc. logo"/>
                        </div>  
                    </div>
                </div>
                <div className="rcorners-title">
                    <h4 >Low-Cost</h4>
                </div>
                <div className="rcorners-text">
                    <p className='text'>Interest rates are as low as 1.5 percent, you just pay for the funding you use.</p>
                </div>
            </div>
            <div className="tab1    ">
                <div className="rcorners">
                    <div className="rcircle">
                        <div className="rcircle1">
                            <img className='FeaturekiImg'src={F6} alt="BigCo Inc. logo"/>
                        </div>  
                    </div>
                </div>
                <div className="rcorners-title">
                    <h4 >Quick Approval</h4>
                </div>
                <div className="rcorners-text">
                    <p className='text'>We aim to process your application within 48 hours for your convenience and ease.</p>
                </div>
            </div>
            </div> 
            </div>
        </div>     
    )
}

export default Featuresanimation
