import React, { useEffect } from "react"
import {Button} from "reactstrap"
import Next from './submit.png'
import './style.css'
import Swal from "sweetalert2"
import Loan2 from './Absolute Assignment Deed.pdf' 
// import { useNavigate } from "react-router-dom"
function Step5() {
    useEffect(() => {
        window.scrollTo(0, 0)
         }, [])
//   const navigate = useNavigate()
  function EssignOTPAssignee() {
    Swal.fire({
        title: 'Adhar Verification',
        html:
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>',
        focusConfirm: true,
        inputAttributes: {
            maxlength: 1,
            autocapitalize: 'off',
            autocorrect: 'off',
            type:'number'
          },
        preConfirm: () => {
        }
      })
 }
      function Successfully() {
        Swal.fire({
title:'Awesome !',
text:'form submitted successfully !',
type:'success'
})
      }
      function EssignOTPWitness() {
        Swal.fire({
          title: 'Adhar Verification',
          html:
          ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
          ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
          ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
          ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
          ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
          ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>',
          focusConfirm: true,
          inputAttributes: {
              maxlength: 1,
              autocapitalize: 'off',
              autocorrect: 'off',
              type:'number'
            },
          preConfirm: () => {
          }
        })
     }
      useEffect(() => {
     window.scrollTo(0, 0)
      }, [])
    return (
          <>
          <h2 className="app-header">Loan Agreement</h2>
        <iframe src={Loan2} width="70%" height="600px  "></iframe>
        <div className="essign">
      <Button  onClick={EssignOTPWitness}>Witness (1) I Had All Read Documents And I Here By Giving My Consent On The Same</Button>
      <Button  onClick={EssignOTPWitness}>Witness (2) I Had All Read Documents And I Here By Giving My Consent On The Same</Button>
       <Button  onClick={EssignOTPAssignee}>Policy Holder I Had All Read Documents And I Here By Giving My Consent On The Same</Button>
       </div>
      <img src={Next} className="In-absolute-button app-header" onClick={Successfully}/>
      </>
    )
}
export default Step5