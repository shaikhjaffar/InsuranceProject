
import React, { useEffect } from "react"
import "./style.css"
// import AgreeButton from "./Next.png"
// import { useNavigate } from "react-router-dom"
import Loan from './Application and Notice of Assignment.pdf'

function Step3() {
    // const navigate = useNavigate()
    useEffect(() => {
      window.scrollTo(0, 0)
       }, [])
   
  return (
     
    // <div className="card">
    //      <div className="Insurance-step">
    //         <div className="step step-active">Step1</div>
    //         <div className="step step-active"onClick={() => navigate('/application2')}>Step2</div>
    //         <div className="step step-active">Step3</div>
    //         <div className="step">Step4</div>
    //         <div className="step">Step5</div>
    //       </div>
    <>
          <h2 className="app-header">Application and Notice of Assignment</h2>
          <iframe src={Loan} width="70%" height="600px  "></iframe>
       {/* <img src={AgreeButton} style={{marginLeft:"40%"}} className="In-absolute-button" onClick={() => navigate('/step4')} /> */}
    </>
  )
}
export default Step3
