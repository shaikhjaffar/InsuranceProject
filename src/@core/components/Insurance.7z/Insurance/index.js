import { useState, useEffect } from "react"
import { Button, Input, Label, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap'
import Step1 from "./step1"
import Step2 from "./step2"
import Step3 from "./step3"
import Step4 from "./step4"
import Step5 from "./step5"
import Next from './Next.png'
import Submit from './submit.png'
import Swal from "sweetalert2"
// import swal from '@sweetalert/with-react'
import Otp from "./otp"
function Insurance() {
  const [step, setStep] = useState('step1')
  const [active2, setactive2] = useState(false)
  const [active3, setactive3] = useState(false)
  const [active4, setactive4] = useState(false)
  const [active5, setactive5] = useState(false)
  const [modal, setModal] = useState(false)
  const [modal1, setModal1] = useState(false)
  const [showOTp, setshowOTp] = useState(false)
  const [showOTp1, setshowOTp1] = useState(false)
  const [showWitness, setShowWitness] = useState(false)
  const [count, setCount] = useState(0)
  const [witnessDetail, setShowWitnessDetail] = useState({
       Relation: "",
       AdharNumber: ""
  })
  const [witness2Detail, setShowWitness2Detail] = useState({
    Relation: "",
    AdharNumber: ""
})
  const [showWitness2, setShowWitness2] = useState(false)
  // const navigate = useNavigate()
  function toggle() {
    setModal(!modal)
    if (modal === false) {
      setshowOTp(false)
    }
  }
  function toggle1() {
    setModal1(!modal1)
    if (modal1 === false) {
      setshowOTp1(false)
    }
  }
 function witness1detail() {
  setShowWitness(!showWitness)
  setCount(count + 1)
  const adharnumber = document.getElementById('witness1-adharnumber').value
  const relation = document.getElementById('witness1-relation').value
  // setShowWitnessDetail(witnessDetail.AdharNumber === witness1adhar)
  // setShowWitnessDetail(witnessDetail.Relation === witness1relation)
  // console.log(setShowWitnessDetail(witnessDetail.AdharNumber))
  setShowWitnessDetail(existingValues => ({
    ...existingValues,
    Relation:relation,
    AdharNumber:adharnumber
  }))
 }
 function witness2detail() {
  setShowWitness2(!showWitness2)
   setCount(count + 1)
  const adharnumber = document.getElementById('witness2-adharnumber').value
  const relation = document.getElementById('witness2-relation').value
  // setShowWitnessDetail(witnessDetail.AdharNumber === witness1adhar)
  // setShowWitnessDetail(witnessDetail.Relation === witness1relation)
  // console.log(setShowWitnessDetail(witnessDetail.AdharNumber))
  setShowWitness2Detail(existingValues => ({
    ...existingValues,
    Relation:relation,
    AdharNumber:adharnumber
  }))
 }


    useEffect(() => {
    window.scrollTo(0, 0)
     }, [step])
  function AlertOtp() {
    Swal.fire({
        title: 'Adhar Verification',
        html:' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>' +
        ' <input  autocomplete="off" class="swal2-input" maxlength="1"/>',
        focusConfirm: true,
        inputAttributes: {
            autocapitalize: 'off',
            autocorrect: 'off',
            type:'number'
          },
        preConfirm: () => {
            setStep('step2')
            setactive2(true)
        }
      })
 }
     return (
        <div className="card">
        <div className="Insurance-step">
          <div className="step step-active">Step1</div>
          <div className={active2 ? "step step-active" : "step"} onClick={
            () => {
              if (active2 === true) {
                setStep('step2')
              }
            }
          }>Step2</div>
          <div  className={active3 ? "step step-active" : "step"}
          onClick={
            () => {
              if (active3 === true) {
                setStep('step3')
              }
            }
          }>Step3</div>
          <div  className={active4 ? "step step-active" : "step"}
          onClick={
            () => {
              if (active4 === true) {
                setStep('step4')
              }
            }
          }>Step4</div>
          <div  className={active5 ? "step step-active" : "step"}
          onClick={
            () => {
              if (active5 === true) {
                setStep('step5')
              }
            }
          }>Step5</div>
        </div>
        {(() => {
            switch (step) {
              case 'step1':
                return (
                    <><Step1 />
                    <img src={Submit}  className="In-absolute-button app-header" onClick={AlertOtp}/>
                    </>
                )
              case 'step2':
                return (
                    <><Step2/> 
                                <div>
            <Modal isOpen={modal} toggle={toggle}>
        <ModalHeader toggle={toggle}>Witness Authentication</ModalHeader>
        <ModalBody>
        <label>Adhar Number</label>
           <input className='spacing stop' id="witness1-adharnumber"></input>
           <label>Relationship with Assignor</label>
           <input className='spacing stop' id="witness1-relation"></input>
           {
            showOTp ? <div><label>Enter OTP</label><input className='spacing stop'></input></div> : <></>
           }
        </ModalBody>
        <ModalFooter>
          {
            showOTp ? <Button color="primary" onClick={() => { witness1detail(); toggle() }}>Verify</Button> : <Button color="primary" onClick={() => setshowOTp(!showOTp)}>Request for OTP</Button>
          }
          <Button color="secondary" onClick={toggle}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
      <Modal isOpen={modal1} toggle={toggle1}>
        <ModalHeader toggle={toggle1}>Witness Authentication</ModalHeader>
        <ModalBody>
        <label>Adhar Number</label>
           <input className='spacing stop' id="witness2-adharnumber"></input>
           <label>Relationship with Assignor</label>
           <input className='spacing stop' id="witness2-relation"></input>
           {
            showOTp1 ? <div><label>Enter OTP</label><input className='spacing stop'></input> </div> : <></>
           }
        </ModalBody>
        <ModalFooter>
          {
            showOTp1 ? <Button color="primary" onClick={() => { witness2detail(); toggle1() }}>Verify</Button> : <Button color="primary" onClick={() => setshowOTp1(!showOTp1)}>Request for OTP</Button>
          }
          <Button color="secondary" onClick={toggle1}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </div> {
      showWitness ? <section  className='witness-detail'>
      <h2 className="app-header">Witness1 Detail</h2> 
      <div className="personal-detail">
     <div className="app-form-input">
       <label>Name of Witness</label>
       <label>Mukesh Kumar</label>
      {/* <input></input> */}
       </div>
       <div className="app-form-input">
       <label>Relationship with Assignor</label>
       <label id="witness1-relation-detail">{witnessDetail.Relation}</label>
      {/* <input></input> */}
       </div>
       <div className="app-form-input">
       <label>Mobile Number</label>
       <label>989732829</label>
      {/* <input></input> */}
       </div>
       <div className="app-form-input">
       <label>Adhar Number</label>
       <label id="witness1-adhar-detail">{witnessDetail.AdharNumber}</label>
      {/* <input></input> */}
       </div>
       <div className="app-form-input">
       <label>Address</label>
       <label>powai</label>
      {/* <input></input> */}
       </div>
       </div>
       </section> : <div style={{display:"flex", gap:"20px", marginLeft:"50%"}}><Button style={{width:"200px"}} onClick={toggle}>Click here to fill witness1 detail</Button></div>
    }
     {
      showWitness2 ? <section className='witness-detail'>
      <h2 className="app-header">Witness2 Detail</h2> 
      <div className="personal-detail">
     <div className="app-form-input">
       <label>Name of Witness</label>
       <label>Nitesh Kumar</label>
      {/* <input></input> */}
       </div>
       <div className="app-form-input">
       <label>Relationship with Assignor</label>
       <label id="witness2-relation-detail">{witness2Detail.Relation}</label>
      {/* <input></input> */}
       </div>
       <div className="app-form-input">
       <label>Mobile Number</label>
       <label>345678909809</label>
      {/* <input></input> */}
       </div>
       <div className="app-form-input">
       <label>Adhar Number</label>
       <label id="witness2-adhar-detail">{witness2Detail.AdharNumber}</label>
       </div>
       <div className="app-form-input">
       <label>Address</label>
       <label>Powai</label>
       </div>
       </div>
       {
         count === 2 ?  <img src={Next}  className="In-absolute-button app-header" onClick={() => { setStep('step3'); setactive3(true) }}/> : <></>
       }
       </section> : <div style={{ marginLeft:"50%", marginTop:"40px"}}><Button style={{width:"200px"}} onClick={toggle1}>Click here to fill witness2 detail</Button></div>
    }
                   
                    </>
                )
              case 'step3':
                return (
                    <><Step3/>
                    <img src={Next}  className="In-absolute-button app-header" onClick={() => { setStep('step4'); setactive4(true) }}/>
                    </>
                )
              case 'step4':
                return (
                    <><Step4/>
                    <img src={Next}  className="In-absolute-button app-header" onClick={() => { setStep('step5'); setactive5(true) }}/>
                    </>
                )
                case 'step5':
                return <Step5/>
              default:
                return <Step1/>
            }
          })()}

        </div>
     )
}
 export default Insurance