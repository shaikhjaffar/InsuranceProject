import React, { useEffect } from "react"
// import { useNavigate } from "react-router-dom"
// import Next from './Next.png'
import Loan1 from './Absolute Assignment Deed.pdf' 
function Step4() {
    // const navigate = useNavigate()
    useEffect(() => {
        window.scrollTo(0, 0)
         }, [])
    return (
         <>
          <h2 className="app-header">Absolute Assignment Deed</h2>
          <iframe src={Loan1} width="70%" height="600px  "></iframe>
      {/* <img src={Next}  className="In-absolute-button app-header" onClick={() => navigate('/step5')}/> */}
      </>
    )
}
export default Step4