import './Calendar.css'
import React, { useState }  from 'react'
import Line1 from './Calendartopline.png'
import Arrow1 from './Unionarrow - L.png'
import Arrow2 from './Unionarrow - R.png'
function Calendarstyle() {
  const current = new Date()
  const [mstate] = useState([
    { id:1, name: 'January'},
    { id:2, name: 'February'},
    { id:3, name: 'March'},
    { id:4, name: 'April'},
    { id:5, name: 'May'},
    { id:6, name: 'June'},
    { id:7, name: 'July'},
    { id:8, name: 'August'},
    { id:9, name: 'September'},
    { id:10, name: 'October'},
    { id:11, name: 'November'},
    { id:12, name: 'December'}
  ])
  const date = current.getMonth() + 1
  let first = ""
  mstate.map((ms) => { 
    if (ms.id === date) {
     first = ms.name 
    }
  })
  const [name, setName] = useState(first)
  
  return (
    <div className="call-div">
      <div className='col-of-calendar'>
        <div className='button-container'>
          <div className='round-button-designl '></div>
          <img className="Arrow-Line-Imagel " src={Arrow1} alt="BigCo Inc. logo"/>
          <button className='Button-of-Calendar ' >{2022}</button>
          <img className="Arrow-Line-Imager " src={Arrow2} alt="BigCo Inc. logo"/>
          <div className='round-button-designr '></div>
        </div>
        <img className="Calendar-Line-Image" src={Line1} alt="BigCo Inc. logo"/>
      </div>
      <div className='col-of-calendar2'>
        <div className='button-container'>
          <div className='round-button-designl'></div>
          <img className="Arrow-Line-Imagel" src={Arrow1} alt="BigCo Inc. logo" 
            onClick={() => {
              if (name === "January") {
                setName("December")
              } else if (name === "February") {
                setName("January")
              } else if (name === "March") {
                setName("February")
              } else if (name === "April") {
                setName("March")
              } else if (name === "May") {
                setName("April")
              } else if (name === "June") {
                setName("May")
              } else if (name === "July") {
                setName("June")
              } else if (name === "August") {
                setName("July")
              } else if (name === "September") {
                setName("August")
              } else if (name === "October") {
                setName("September")
              } else if (name === "November") {
                setName("October")
              } else if (name === "December") {
                setName("November")
              }
                }}/>
          <button className='Button-of-Calendar2 '>{name}</button>
          <img className="Arrow-Line-Imager" src={Arrow2} alt="BigCo Inc. logo"
            onClick={() => {
              if (name === "January") {
                setName("February")
              } else if (name === "February") {
                setName("March")
              } else if (name === "March") {
                setName("April")
              } else if (name === "April") {
                setName("May")
              } else if (name === "May") {
                setName("June")
              } else if (name === "June") {
                setName("July")
              } else if (name === "July") {
                setName("August")
              } else if (name === "August") {
                setName("September")
              } else if (name === "September") {
                setName("October")
              } else if (name === "October") {
                setName("November")
              } else if (name === "November") {
                setName("December")
              } else if (name === "December") {
                setName("January")
              }
                }}/>
          <div className='round-button-designr'></div>
        </div>
        <div className='Month-names-Left'>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 1) setName(ms.name) })}>Jan</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 2) setName(ms.name) })}>Feb</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 3) setName(ms.name) })}>Mar</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 4) setName(ms.name) })}>Apr</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 5) setName(ms.name) })}>May</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 6) setName(ms.name) })}>Jun</h4>
        </div>
        <div className='Month-names-Right'>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 7) setName(ms.name) })}>Jul</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 8) setName(ms.name) })}>Aug</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 9) setName(ms.name) })}>Sep</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 10) setName(ms.name) })}>Oct</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 11) setName(ms.name) })}>Nov</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 12) setName(ms.name) })}>Dec</h4>
        </div>
        <div className='Month-names-mLeftt'>
          <h4 className='Month-Name'onClick={() => mstate.map((ms) => { if (ms.id === 1) setName(ms.name) })}>Jan</h4>
          <h4 className='Month-Name'onClick={() => mstate.map((ms) => { if (ms.id === 2) setName(ms.name) })}>Feb</h4>
          <h4 className='Month-Name'onClick={() => mstate.map((ms) => { if (ms.id === 3) setName(ms.name) })}>Mar</h4>
        </div>
        <div className='Month-names-mRightt'>
          <h4 className='Month-Name'onClick={() => mstate.map((ms) => { if (ms.id === 7) setName(ms.name) })}>Jul</h4>
          <h4 className='Month-Name'onClick={() => mstate.map((ms) => { if (ms.id === 8) setName(ms.name) })}>Aug</h4>
          <h4 className='Month-Name'onClick={() => mstate.map((ms) => { if (ms.id === 9) setName(ms.name) })}>Sep</h4>
        </div>
        <img className="Calendar-Line-Image2" src={Line1} alt="BigCo Inc. logo"/>
        <div className='Month-names-mLeftb'>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 4) setName(ms.name) })}>Apr</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 5) setName(ms.name) })}>May</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 6) setName(ms.name) })}>Jun</h4>
        </div>
        <div className='Month-names-mRightb'>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 10) setName(ms.name) })}>Oct</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 11) setName(ms.name) })}>Nov</h4>
          <h4 className='Month-Name' onClick={() => mstate.map((ms) => { if (ms.id === 12) setName(ms.name) })}>Dec</h4>
        </div>
      </div>    
    </div>
  )
}

export default Calendarstyle