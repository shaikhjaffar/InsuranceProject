import "@styles/base/components/_card.scss"
import "./style.css"
import Content from "./fetch"
import Bloghead from "./bloghead/index"
const Blog = () => {
    return (
      <div className="blog card">
           <Bloghead/>
        <section className="main">
          <Content/>
        </section>
      </div>
    )
  }

export default Blog
